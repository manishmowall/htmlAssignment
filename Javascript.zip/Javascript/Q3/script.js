$(document).ready(function(){
	var library = [ 
   {
       author: 'Bill Gates',
       title: 'The Road Ahead',
       readingStatus: true
   },
   {
       author: 'Steve Jobs',
       title: 'Walter Isaacson',
       readingStatus: true
   },
   {
       author: 'Suzanne Collins',
       title:  'Mockingjay: The Final Book of The Hunger Games', 
       readingStatus: 'false'
   }];


var $table = $( "<table></table>" );
 var $line = $( "<tr></tr>" );
$line.append( $( "<td></td>" ).html('Author' ) );
    $line.append( $( "<td></td>" ).html( 'Title') );
	$line.append( $( "<td></td>" ).html( 'readingStatus' ) );
    $table.append( $line );
for ( var i = 0; i < library.length; i++ ) {
    var lib = library[i];
    var $line = $( "<tr></tr>" );
    $line.append( $( "<td></td>" ).html( lib.author ) );
    $line.append( $( "<td></td>" ).html( lib.title ) );
	$line.append( $( "<td></td>" ).html( lib.readingStatus ) );
    $table.append( $line );
}

$table.appendTo( document.body );

$table.appendTo( $( "#myDiv" ) );
}
);