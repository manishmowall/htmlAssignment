window.onload = function () {
  var name = prompt("Please enter your name", "Nitish Mowall");

  
   var word1=prompt("Enter a word(exclamation):- ","Ouch");
   var word2=prompt("Enter a word(adverb):- ","stupidly");
   var word3=prompt("Enter a word(noun):- ","car");
   var word4=prompt("Enter a word(noun):- ","drove");
   var word5=prompt("Enter a word(adjective):- ","brave");
   
   var color='#000000';  
color = prompt('Enter the color name in hex value', '#ff0000');
     var color1="\"display: inline;color:"+color+";\""; 
      document.write("<h3>My Mad-libs Story</h3>");
      document.write( "<div style="+ color1 +">"+word1+"</div>! he said "+"<div style="+ color1 +">"+word2+"</div> as he jumped into his convertible ");
	  document.write("<div style="+ color1 +">"+word3+"</div>and "+"<div style="+ color1 +">"+word4+"</div> off with his "+"<div style="+ color1 +">"+ word5+" </div> wife.");
      document.write('<br />');
   


    
  }

