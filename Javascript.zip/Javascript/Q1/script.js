window.onload = function () {
  document.write("Web Broswer : " + navigator.appName);
  document.write("<br />");
  document.write("Height of Window: " + window.screen.availHeight);
  document.write("<br />");
  document.write("Width of Window: " + window.screen.availWidth);
  document.write("<br />");
  document.write("Last Modified : " + document.lastModified);
}
