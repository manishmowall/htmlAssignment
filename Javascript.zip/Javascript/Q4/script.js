window.onload = function () {
  var person = prompt("Please enter your name", "Nitish Mowall");

  if (person)
  {    alert('Hello ' + person + '!');
    document.write("<h1>Hello " + person +"!</h1>");


  }
}
