window.onload = function () {
  var jarray = document.getElementById('jarray');
  var btnInput = document.getElementById('button');

  btnInput.addEventListener('click', function (event) {
    var inputArray = jarray.value.split(',');
    var array = [];

    for(var i = 0; i < inputArray.length; i++)
      array.push(parseInt(inputArray[i].trim()));

    var answer = findDuplicates(array);
    var result = document.getElementById('output');
  console.log(answer);
    if(answer.length ==0)
		 result.innerHTML = 'The Array contains distinct elements';  
     
    else
          result.innerHTML = 'The Array contains duplicates of elements : '+answer;
  });
}

function findDuplicates(inputArray) {
  var answer =[];
  
  for (var i = 0; i < inputArray.length; i++)
  {
    var item = inputArray[i];
//	console.log(item);
    if(item != null){
//console.log(item);		
      var count=0;      
      let idx = inputArray.indexOf(item);
  //    console.log(idx);
      while(idx != -1) {
		 // console.log(item);
        inputArray[idx]=null;   
        count +=1;
	   idx = inputArray.indexOf(item, idx + 1);
        
      }
if(count >=2){  

        answer.push(item);        
        }
 
   }
   
}

  return answer;
}
